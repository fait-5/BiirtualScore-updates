$ErrorActionPreference = "Stop"

Write-Host "====================================="
Write-Host "   BSCloudService Updater iniciado"
Write-Host "====================================="

# CONFIGURACIÓN
$baseDir = "C:\Users\Usuario\Desktop\proj\CallingSystem-master\BiirtualScore.CallingSystem.BSCloudService\bin"
$newVersionDir = $PSScriptRoot  # Carpeta root donde se encuentra BSCLOUDSERVICE-UPDATER.ps1

$oldDebug = Join-Path $baseDir "Debug"
$backupDebug = Join-Path $baseDir "Debug_ant"
$newDebugSource = Join-Path $newVersionDir "Debug"

$configFileName = "BiirtualScore.CallingSystem.BSCloudService.exe.config"

function Rollback {
    Write-Host "Ejecutando rollback..."

    if (Test-Path $oldDebug) {
        Remove-Item $oldDebug -Recurse -Force
    }

    if (Test-Path $backupDebug) {
        Rename-Item $backupDebug "Debug"
    }

    Write-Host "Rollback completado"
}

try {
    # 1. Eliminar backup anterior si existe
    if (Test-Path $backupDebug) {
        Write-Host "Eliminando Debug_ant anterior..."
        Remove-Item $backupDebug -Recurse -Force
    }

    # 2. Renombrar Debug a Debug_ant
    if (Test-Path $oldDebug) {
        Write-Host "Renombrando Debug a Debug_ant..."
        Rename-Item $oldDebug "Debug_ant"
    }
    else {
        throw "No se encontró la carpeta Debug original"
    }

    # 3. Copiar nueva versión
    if (-not (Test-Path $newDebugSource)) {
        throw "No se encontró la carpeta Debug en el paquete descargado"
    }

    Write-Host "Copiando nueva versión..."
    Copy-Item $newDebugSource -Destination $baseDir -Recurse -Force

    $newDebug = Join-Path $baseDir "Debug"

    # 4. Restaurar ffmpeg.exe si existe
    $oldFfmpeg = Join-Path $backupDebug "ffmpeg.exe"
    $newFfmpeg = Join-Path $newDebug "ffmpeg.exe"

    if (Test-Path $oldFfmpeg) {
        Write-Host "Restaurando ffmpeg.exe..."
        Copy-Item $oldFfmpeg -Destination $newFfmpeg -Force
    }

    # 5. Migrar configuración
    $oldConfig = Join-Path $backupDebug $configFileName
    $newConfig = Join-Path $newDebug $configFileName

    if (-not (Test-Path $oldConfig) -or -not (Test-Path $newConfig)) {
        throw "No se encontraron los archivos de configuración"
    }

    Write-Host "Migrando configuración..."

    [xml]$oldXml = Get-Content $oldConfig
    [xml]$newXml = Get-Content $newConfig

    function CopySetting($key) {
        $oldNode = $oldXml.configuration.appSettings.add | Where-Object { $_.key -eq $key }
        $newNode = $newXml.configuration.appSettings.add | Where-Object { $_.key -eq $key }

        if ($oldNode -and $newNode) {
            $newNode.value = $oldNode.value
        }
    }

    CopySetting "PosId"
    CopySetting "Secret"
    CopySetting "PendingBusinessId"

    $newXml.Save($newConfig)

    Write-Host "Configuración migrada correctamente"

    Write-Host "Actualización completada correctamente"
    exit 0
}
catch {
    Write-Host "Error durante la actualización:"
    Write-Host $_

    Rollback

    exit 1
}