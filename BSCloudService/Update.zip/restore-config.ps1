param()

$configName  = 'BiirtualScore.CallingSystem.BSCloudService.exe.config'
$TARGET      = if ($env:BS_TARGET) { $env:BS_TARGET } else { $PSScriptRoot }
$BACKUP      = Join-Path (Split-Path $TARGET -Parent) 'Debug_ant'
$t           = Join-Path $TARGET $configName
$b           = Join-Path $BACKUP $configName
$identityFile= Join-Path $TARGET 'client_identity.txt'

$credMap = @{
    'CLUB BILLARES BARCELONA' = @{
        ConnectionString  = 'hEt05Xo7Wwns0mqarZ/qH39FIF3GoCkDQpAerJW1qNp2Bg46LUOV44XtD9aVG0o8'
        DatabaseName      = 'biirtualscore'
        BaseUrl           = 'https://api.biirtualscore.com'
        PosId             = 'bfc4b48e-e3aa-45e7-88ef-6fd7b7048f0e'
        Secret            = 't59pxfbpNoV-'
        PendingBusinessId = '0aece5b8-71ed-419b-aee1-dd9c06648cda'
    }
    'BILLARES MASTER VIP ENVIGADO' = @{
        ConnectionString  = 'hEt05Xo7Wwns0mqarZ/qH39FIF3GoCkDQpAerJW1qNp2Bg46LUOV44XtD9aVG0o8'
        DatabaseName      = 'biirtualscore'
        BaseUrl           = 'https://api.biirtualscore.com'
        PosId             = '5b0572cb-57cb-4093-b6fe-edb2e8547d1c'
        Secret            = '3KuuSFYs@9.n'
        PendingBusinessId = '2e4fe1a8-35da-4df7-bca0-40da973e8f19'
    }
}

if (-not (Test-Path $t)) { exit 1 }

$x = [xml](Get-Content $t -Raw)

$posIdNode   = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'PosId' }
$baseUrlNode = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'BaseUrl' }
$posIdEmpty  = $posIdNode  -and [string]::IsNullOrWhiteSpace($posIdNode.value)
$baseUrlDev  = $baseUrlNode -and ($baseUrlNode.value -eq 'http://104.198.190.1')

if (Test-Path $identityFile) {
    $clientName = (Get-Content $identityFile -Raw).Trim()
    if ($credMap.ContainsKey($clientName)) {
        $creds = $credMap[$clientName]
        foreach ($k in $creds.Keys) {
            $node = $x.configuration.appSettings.add | Where-Object { $_.key -eq $k }
            if ($node) { $node.value = $creds[$k] }
        }
    }
} elseif ($posIdEmpty -or $baseUrlDev) {
    # Config corrompido y no hay identity file: no podemos identificar el cliente,
    # pero al menos restauramos BaseUrl correcta si estaba en dev
    if ($baseUrlDev) {
        $baseUrlNode.value = 'https://api.biirtualscore.com'
    }
} elseif (Test-Path $b) {
    $old = [xml](Get-Content $b -Raw)
    foreach ($k in @('ConnectionString', 'DatabaseName', 'BaseUrl', 'PosId', 'Secret', 'PendingBusinessId')) {
        $ov = $old.configuration.appSettings.add | Where-Object { $_.key -eq $k }
        $nv = $x.configuration.appSettings.add | Where-Object { $_.key -eq $k }
        if ($ov -and $nv) { $nv.value = $ov.value }
    }
}

$vn = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'Version' }
if ($vn) { $vn.value = '1.2.15.0' }

$x.Save($t)
