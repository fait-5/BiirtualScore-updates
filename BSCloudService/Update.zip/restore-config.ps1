$configName = 'BiirtualScore.CallingSystem.BSCloudService.exe.config'
$TARGET = Join-Path $env:ProgramW6432 'BiirtualScore\BsCloudService'
$BACKUP = Join-Path $env:ProgramW6432 'BiirtualScore\Debug_ant'
$t = Join-Path $TARGET $configName
$b = Join-Path $BACKUP $configName
$identityFile = Join-Path $TARGET 'client_identity.txt'

$credMap = @{
    'CLUB BILLARES BARCELONA' = @{
        ConnectionString  = 'hEt05Xo7Wwns0mqarZ/qH39FIF3GoCkDQpAerJW1qNp2Bg46LUOV44XtD9aVG0o8'
        DatabaseName      = 'biirtualscore'
        BaseUrl           = 'https://api.biirtualscore.com'
        PosId             = 'bfc4b48e-e3aa-45e7-88ef-6fd7b7048f0e'
        Secret            = 't59pxfbpNoV-'
        PendingBusinessId = '0aece5b8-71ed-419b-aee1-dd9c06648cda'
    }
}

$x = [xml](Get-Content $t -Raw)

# Si ya existe el archivo de identidad, usar el mapa de credenciales
if (Test-Path $identityFile) {
    $clientName = (Get-Content $identityFile -Raw).Trim()
    if ($credMap.ContainsKey($clientName)) {
        $creds = $credMap[$clientName]
        foreach ($k in $creds.Keys) {
            $node = $x.configuration.appSettings.add | Where-Object { $_.key -eq $k }
            if ($node) { $node.value = $creds[$k] }
        }
    }
}
# Si no hay archivo de identidad aún, intentar restaurar del backup
elseif (Test-Path $b) {
    $old = [xml](Get-Content $b -Raw)
    foreach ($k in @('ConnectionString', 'DatabaseName', 'BaseUrl', 'PosId', 'Secret', 'PendingBusinessId')) {
        $ov = $old.configuration.appSettings.add | Where-Object { $_.key -eq $k }
        $nv = $x.configuration.appSettings.add | Where-Object { $_.key -eq $k }
        if ($ov -and $nv) { $nv.value = $ov.value }
    }
}

$vn = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'Version' }
if ($vn) { $vn.value = '1.2.2.0' }

$x.Save($t)
