param()

$configName = 'BiirtualScore.CallingSystem.BSCloudService.exe.config'
$TARGET     = if ($env:BS_TARGET) { $env:BS_TARGET } else { $PSScriptRoot }
$BACKUP     = Join-Path (Split-Path $TARGET -Parent) 'Debug_ant'
$t          = Join-Path $TARGET $configName
$b          = Join-Path $BACKUP $configName

if (-not (Test-Path $t)) { exit 1 }
if (-not (Test-Path $b)) { exit 0 }

$new = [xml](Get-Content $t -Raw)
$old = [xml](Get-Content $b -Raw)

foreach ($oldNode in $old.configuration.appSettings.add) {
    if ($oldNode.key -eq 'Version') { continue }
    $newNode = $new.configuration.appSettings.add | Where-Object { $_.key -eq $oldNode.key }
    if ($newNode) { $newNode.value = $oldNode.value }
}

$new.Save($t)
