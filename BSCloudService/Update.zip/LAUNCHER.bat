@echo off
setlocal

set "TARGET=%ProgramW6432%\BiirtualScore\BsCloudService"
set "BACKUP=%ProgramW6432%\BiirtualScore\Debug_ant"

:: Backup current installation
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Copy all new files including clean config template
robocopy "%~dp0." "%TARGET%" /XF *.bat /XF *.ps1 /IS /IT /NJH /NJS /NS /NC

:: Restore AppSettings from backup and set Version
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0restore-config.ps1"

exit /b 0
