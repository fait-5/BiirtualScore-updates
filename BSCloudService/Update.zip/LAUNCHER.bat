@echo off
setlocal
cd /d "%SystemRoot%"

set "PF=%ProgramW6432%"
if "%PF%"=="" set "PF=%PROGRAMFILES%"
set "TARGET=%PF%\BiirtualScore\BsCloudService"
set "BACKUP=%PF%\BiirtualScore\Debug_ant"
set "BS_TARGET=%TARGET%"

:: Copiar nuevos archivos PRIMERO (gana a CleanupTemp que llega ~3s despues)
robocopy "%~dp0." "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC /NDL /NP

:: Arrancar BSCloudService temporalmente para que genere client_identity.txt
sc start BiirtualScoreBSCloudService >nul 2>&1

:: Esperar hasta 15s a que aparezca client_identity.txt (sale antes si ya existe)
set /a _w=0
:waitloop
if exist "%TARGET%\client_identity.txt" goto :dostopit
if %_w% geq 15 goto :dostopit
timeout /t 1 /nobreak >nul 2>&1
set /a _w+=1
goto waitloop

:dostopit
:: Detener el servicio antes de restaurar el config
sc stop BiirtualScoreBSCloudService >nul 2>&1
timeout /t 15 /nobreak >nul 2>&1

:: Backup de la instalacion anterior
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Restaurar configuracion desde TARGET (inmune a CleanupTemp)
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"

:: Limpiar ps1 de TARGET
del /q "%TARGET%\restore-config.ps1" >nul 2>&1

exit /b 0
