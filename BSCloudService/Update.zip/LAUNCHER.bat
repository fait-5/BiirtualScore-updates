@echo off
setlocal

:: Liberar lock sobre la carpeta temp cambiando el directorio de trabajo
cd /d "%SystemRoot%"

:: Si ya estamos corriendo desde el directorio estable, hacer el trabajo real
if "%~1"=="--stable" goto :do_work

:: Primera invocación: copiar todo a un directorio estable fuera del alcance de CleanupTemp
:: CleanupTemp borra C:\Windows\SystemTemp\BSCloudServiceUpdate — nunca toca C:\Windows\Temp
set "STABLE=%SystemRoot%\Temp\BSCloudUpdate_stable"
if exist "%STABLE%" rd /s /q "%STABLE%"
xcopy /s /e /y /i /q "%~dp0." "%STABLE%\" >nul 2>&1
call "%STABLE%\LAUNCHER.bat" --stable
exit /b %ERRORLEVEL%

:do_work
set "TARGET=%ProgramW6432%\BiirtualScore\BsCloudService"
set "BACKUP=%ProgramW6432%\BiirtualScore\Debug_ant"

:: Backup current installation
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Copiar restore-config.ps1 al directorio del servicio
copy /y "%~dp0restore-config.ps1" "%TARGET%\restore-config.ps1" >nul

:: Copiar todos los archivos nuevos al directorio de instalación
robocopy "%~dp0." "%TARGET%" /XF *.bat /XF *.ps1 /IS /IT /NJH /NJS /NS /NC

:: Ejecutar restore-config desde TARGET
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"

:: Limpiar ps1 del directorio del servicio
del /q "%TARGET%\restore-config.ps1" >nul 2>&1

exit /b 0
