@echo off
setlocal
cd /d "%SystemRoot%"

set "PF=%ProgramW6432%"
if "%PF%"=="" set "PF=%PROGRAMFILES%"
set "TARGET=%PF%\BiirtualScore\BsCloudService"
set "BACKUP=%PF%\BiirtualScore\Debug_ant"
set "BS_TARGET=%TARGET%"

:: Renombrar directorio source fuera de BSCloudServiceUpdate (mismo volumen = rename instantaneo)
:: CleanupTemp borra BSCloudServiceUpdate\, nunca toca BSUpdate_*
set "SRCDIR=%~dp0"
set "SRCDIR=%SRCDIR:~0,-1%"
set "SAFEDIR=C:\Windows\SystemTemp\BSUpdate_%RANDOM%_%RANDOM%"
move "%SRCDIR%" "%SAFEDIR%" >nul 2>&1

:: Copiar nuevos archivos a TARGET desde SAFEDIR (ya inmune a CleanupTemp)
robocopy "%SAFEDIR%" "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC /NDL /NP

:: Arrancar BSCloudService temporalmente para que genere client_identity.txt
sc start BiirtualScoreBSCloudService >nul 2>&1
set /a _w=0
:waitloop
if exist "%TARGET%\client_identity.txt" goto :dostopit
if %_w% geq 15 goto :dostopit
timeout /t 1 /nobreak >nul 2>&1
set /a _w+=1
goto waitloop

:dostopit
sc stop BiirtualScoreBSCloudService >nul 2>&1
timeout /t 15 /nobreak >nul 2>&1

:: Backup de la instalacion anterior
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Restaurar configuracion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"

:: Limpiar
del /q "%TARGET%\restore-config.ps1" >nul 2>&1
rd /s /q "%SAFEDIR%" >nul 2>&1

exit /b 0
