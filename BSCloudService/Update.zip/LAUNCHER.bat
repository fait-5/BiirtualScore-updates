@echo off
setlocal

set "TARGET=%ProgramW6432%\BiirtualScore\BsCloudService"
set "BACKUP=%ProgramW6432%\BiirtualScore\Debug_ant"

:: Backup current installation
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Copy all new files including clean config template
robocopy "%~dp0." "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC

:: Restore AppSettings from backup into new config, then set Version
powershell -NoProfile -NonInteractive -Command ^
  "& { $t = [System.IO.Path]::Combine($env:ProgramW6432, 'BiirtualScore', 'BsCloudService', 'BiirtualScore.CallingSystem.BSCloudService.exe.config');" ^
  "$b = [System.IO.Path]::Combine($env:ProgramW6432, 'BiirtualScore', 'Debug_ant', 'BiirtualScore.CallingSystem.BSCloudService.exe.config');" ^
  "$x = [xml](Get-Content $t -Raw);" ^
  "if (Test-Path $b) {" ^
  "  $old = [xml](Get-Content $b -Raw);" ^
  "  foreach ($k in @('ConnectionString','DatabaseName','BaseUrl','PosId','Secret','PendingBusinessId')) {" ^
  "    $ov = $old.configuration.appSettings.add | Where-Object { $_.key -eq $k };" ^
  "    $nv = $x.configuration.appSettings.add | Where-Object { $_.key -eq $k };" ^
  "    if ($ov -and $nv) { $nv.value = $ov.value }" ^
  "  }" ^
  "};" ^
  "$vn = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'Version' };" ^
  "if ($vn) { $vn.value = '1.2.1.0' };" ^
  "$x.Save($t) }"

exit /b 0
