@echo off
setlocal

:: Liberar lock sobre la carpeta temp cambiando el directorio de trabajo
cd /d "%SystemRoot%"

set "TARGET=%ProgramW6432%\BiirtualScore\BsCloudService"
set "BACKUP=%ProgramW6432%\BiirtualScore\Debug_ant"

:: Backup current installation
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Copiar restore-config.ps1 al directorio del servicio ANTES de que temp pueda ser limpiado
copy /y "%~dp0restore-config.ps1" "%TARGET%\restore-config.ps1" >nul

:: Copy all new files including clean config template
robocopy "%~dp0." "%TARGET%" /XF *.bat /XF *.ps1 /IS /IT /NJH /NJS /NS /NC

:: Ejecutar desde TARGET (inmune a limpieza de carpeta temp)
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"

:: Limpiar ps1 del directorio del servicio
del /q "%TARGET%\restore-config.ps1" >nul 2>&1

exit /b 0
