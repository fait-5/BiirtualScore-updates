@echo off
setlocal
cd /d "%SystemRoot%"

set "PF=%ProgramW6432%"
if "%PF%"=="" set "PF=%PROGRAMFILES%"
set "TARGET=%PF%\BiirtualScore\BsCloudService"
set "BACKUP=%PF%\BiirtualScore\Debug_ant"
set "BS_TARGET=%TARGET%"
set "SRCDIR=%~dp0"
set "SRCDIR=%SRCDIR:~0,-1%"

echo [L1] SRCDIR=%SRCDIR%
echo [L2] TARGET=%TARGET%

echo [L3] backup previo...
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1
echo [L4] backup done

echo [L5] robocopy...
robocopy "%SRCDIR%" "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC /NDL /NP
echo [L6] robocopy ERRORLEVEL=%ERRORLEVEL%

echo [L7] powershell restore...
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"
echo [L8] powershell ERRORLEVEL=%ERRORLEVEL%

del /q "%TARGET%\restore-config.ps1" >nul 2>&1

echo [L9] sc start...
sc start BiirtualScoreBSCloudService >nul 2>&1
echo [L10] sc start ERRORLEVEL=%ERRORLEVEL%

echo [L11] DONE
exit /b 0
