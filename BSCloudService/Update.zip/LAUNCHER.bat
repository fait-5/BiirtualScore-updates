@echo off
setlocal

set "TARGET=%ProgramW6432%\BiirtualScore\BsCloudService"
set "BACKUP=%ProgramW6432%\BiirtualScore\Debug_ant"

:: Backup current installation
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: %~dp0. resuelve el directorio fuente sin barra final (evita \" que escapa la comilla)
robocopy "%~dp0." "%TARGET%" /XF *.config /XF *.bat /IS /IT /NJH /NJS /NS /NC

:: Update only the Version key in the existing client config
powershell -NoProfile -NonInteractive -Command "& { $f = '%TARGET%\BiirtualScore.CallingSystem.BSCloudService.exe.config'; if (Test-Path $f) { $x = [xml](Get-Content $f -Raw); $n = $x.configuration.appSettings.add | Where-Object { $_.key -eq 'Version' }; if ($n) { $n.value = '1.2.0.0' } else { $a = $x.CreateElement('add'); $a.SetAttribute('key', 'Version'); $a.SetAttribute('value', '1.2.0.0'); $x.configuration.appSettings.AppendChild($a) | Out-Null }; $x.Save($f) } }"

exit /b 0
