@echo off
setlocal
echo [L1] cd SystemRoot
cd /d "%SystemRoot%"

set "PF=%ProgramW6432%"
if "%PF%"=="" set "PF=%PROGRAMFILES%"
set "TARGET=%PF%\BiirtualScore\BsCloudService"
set "BACKUP=%PF%\BiirtualScore\Debug_ant"
set "BS_TARGET=%TARGET%"
echo [L2] TARGET=%TARGET%
echo [L3] TARGET_EXISTS=
if exist "%TARGET%" echo [L3] TARGET_EXISTS=YES
if not exist "%TARGET%" echo [L3] TARGET_EXISTS=NO

set "SRCDIR=%~dp0"
set "SRCDIR=%SRCDIR:~0,-1%"
set "SAFEDIR=C:\Windows\SystemTemp\BSUpdate_%RANDOM%_%RANDOM%"
echo [L4] SRCDIR=%SRCDIR%
echo [L5] SAFEDIR=%SAFEDIR%

echo [L6] intentando move...
move "%SRCDIR%" "%SAFEDIR%"
echo [L7] move ERRORLEVEL=%ERRORLEVEL%

echo [L8] SAFEDIR_EXISTS=
if exist "%SAFEDIR%" echo [L8] SAFEDIR_EXISTS=YES
if not exist "%SAFEDIR%" echo [L8] SAFEDIR_EXISTS=NO

echo [L9] robocopy...
robocopy "%SAFEDIR%" "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC /NDL /NP
echo [L10] robocopy ERRORLEVEL=%ERRORLEVEL%

echo [L11] sc start...
sc start BiirtualScoreBSCloudService >nul 2>&1
echo [L12] sc start ERRORLEVEL=%ERRORLEVEL%

set /a _w=0
:waitloop
if exist "%TARGET%\client_identity.txt" goto :dostopit
if %_w% geq 15 goto :dostopit
timeout /t 1 /nobreak >nul 2>&1
set /a _w+=1
echo [L13] wait %_w%s...
goto waitloop

:dostopit
echo [L14] sc stop...
sc stop BiirtualScoreBSCloudService >nul 2>&1
timeout /t 15 /nobreak >nul 2>&1
echo [L15] sc stop done

echo [L16] backup...
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1
echo [L17] backup done

echo [L18] powershell restore...
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"
echo [L19] powershell ERRORLEVEL=%ERRORLEVEL%

del /q "%TARGET%\restore-config.ps1" >nul 2>&1
rd /s /q "%SAFEDIR%" >nul 2>&1

echo [L20] DONE
exit /b 0
