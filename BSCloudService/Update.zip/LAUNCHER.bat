@echo off
setlocal
cd /d "%SystemRoot%"

if "%~1"=="--stable" goto :do_work

:: Directorio estable con nombre ÚNICO por invocación — instancias concurrentes no se pisan
set "STABLE=%SystemRoot%\Temp\BSCloudUpdate_%RANDOM%_%RANDOM%"
robocopy "%~dp0." "%STABLE%" /E /IS /IT /NJH /NJS /NS /NC /NDL /NP /R:2 /W:1
call "%STABLE%\LAUNCHER.bat" --stable
set "RC=%ERRORLEVEL%"
rd /s /q "%STABLE%" >nul 2>&1
exit /b %RC%

:do_work
:: Detectar Program Files de forma robusta
set "PF=%ProgramW6432%"
if "%PF%"=="" set "PF=%PROGRAMFILES%"
set "TARGET=%PF%\BiirtualScore\BsCloudService"
set "BACKUP=%PF%\BiirtualScore\Debug_ant"

:: Backup
if exist "%BACKUP%" rd /s /q "%BACKUP%"
if exist "%TARGET%" xcopy /s /e /y /i /q "%TARGET%" "%BACKUP%\" >nul 2>&1

:: Copiar todos los archivos nuevos al directorio de instalación (incluyendo restore-config.ps1)
robocopy "%~dp0." "%TARGET%" /XF *.bat /IS /IT /NJH /NJS /NS /NC /NDL /NP

:: Ejecutar restore-config desde TARGET
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%TARGET%\restore-config.ps1"

:: Limpiar ps1 del directorio del servicio
del /q "%TARGET%\restore-config.ps1" >nul 2>&1

exit /b 0
