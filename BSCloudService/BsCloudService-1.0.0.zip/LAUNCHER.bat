@echo off
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BSCLOUDSERVICE-UPDATER.ps1"
exit /b %errorlevel%