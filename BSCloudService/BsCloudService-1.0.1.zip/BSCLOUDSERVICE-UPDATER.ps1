$ErrorActionPreference = "Stop"

Write-Host "====================================="
Write-Host "   BSCloudService Updater iniciado"
Write-Host "====================================="

# CONFIGURACIÓN
$baseDir = "C:\Program Files\BiirtualScore"
$newVersionDir = $PSScriptRoot  # Carpeta root donde se encuentra BSCLOUDSERVICE-UPDATER.ps1

$oldBsCloudService = Join-Path $baseDir "BsCloudService"
$backupBsCloudService = Join-Path $baseDir "BsCloudService_ant"
$newBsCloudServiceSource = Join-Path $newVersionDir "BsCloudService"

$configFileName = "BiirtualScore.CallingSystem.BSCloudService.exe.config"

function Rollback {
    Write-Host "Ejecutando rollback..."

    if (Test-Path $oldBsCloudService) {
        Remove-Item $oldBsCloudService -Recurse -Force
    }

    if (Test-Path $backupBsCloudService) {
        Rename-Item $backupBsCloudService "BsCloudService"
    }

    Write-Host "Rollback completado"
}

try {
    # 1. Eliminar backup anterior si existe
    if (Test-Path $backupBsCloudService) {
        Write-Host "Eliminando BsCloudService_ant anterior..."
        Remove-Item $backupBsCloudService -Recurse -Force
    }

    # 2. Renombrar BsCloudService a BsCloudService_ant
    if (Test-Path $oldBsCloudService) {
        Write-Host "Renombrando BsCloudService a BsCloudService_ant..."
        Rename-Item $oldBsCloudService "BsCloudService_ant"
    }
    else {
        throw "No se encontró la carpeta BsCloudService original"
    }

    # 3. Copiar nueva versión
    if (-not (Test-Path $newBsCloudServiceSource)) {
        throw "No se encontró la carpeta BsCloudService en el paquete descargado"
    }

    Write-Host "Copiando nueva versión..."
    Copy-Item $newBsCloudServiceSource -Destination $baseDir -Recurse -Force

    $newBsCloudService = Join-Path $baseDir "BsCloudService"

    # 4. Restaurar ffmpeg.exe si existe
    $oldFfmpeg = Join-Path $backupBsCloudService "ffmpeg.exe"
    $newFfmpeg = Join-Path $newBsCloudService "ffmpeg.exe"

    if (Test-Path $oldFfmpeg) {
        Write-Host "Restaurando ffmpeg.exe..."
        Copy-Item $oldFfmpeg -Destination $newFfmpeg -Force
    }

    # 5. Migrar configuración
    $oldConfig = Join-Path $backupBsCloudService $configFileName
    $newConfig = Join-Path $newBsCloudService $configFileName

    if (-not (Test-Path $oldConfig) -or -not (Test-Path $newConfig)) {
        throw "No se encontraron los archivos de configuración"
    }

    Write-Host "Migrando configuración..."

    [xml]$oldXml = Get-Content $oldConfig
    [xml]$newXml = Get-Content $newConfig

    function CopySetting($key) {
        $oldNode = $oldXml.configuration.appSettings.add | Where-Object { $_.key -eq $key }
        $newNode = $newXml.configuration.appSettings.add | Where-Object { $_.key -eq $key }

        if ($oldNode -and $newNode) {
            $newNode.value = $oldNode.value
        }
    }

    CopySetting "PosId"
    CopySetting "Secret"
    CopySetting "PendingBusinessId"

    $newXml.Save($newConfig)

    Write-Host "Configuración migrada correctamente"

    Write-Host "Actualización completada correctamente"
    exit 0
}
catch {
    Write-Host "Error durante la actualización:"
    Write-Host $_

    Rollback

    exit 1
}